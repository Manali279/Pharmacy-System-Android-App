package com.example.pharmacysystem;

public class PurchaseData {
    private String purchase_type,purchase_address,purchase_company,purchase_quantity,purchase_price,purchase_amount;

    public String getPurchase_type() {
        return purchase_type;
    }

    public void setPurchase_type(String purchase_type) {
        this.purchase_type = purchase_type;
    }

    public String getPurchase_address() {
        return purchase_address;
    }

    public void setPurchase_address(String purchase_address) {
        this.purchase_address = purchase_address;
    }

    public String getPurchase_company() {
        return purchase_company;
    }

    public void setPurchase_company(String purchase_company) {
        this.purchase_company = purchase_company;
    }

    public String getPurchase_quantity() {
        return purchase_quantity;
    }

    public void setPurchase_quantity(String purchase_quantity) {
        this.purchase_quantity = purchase_quantity;
    }

    public String getPurchase_price() {
        return purchase_price;
    }

    public void setPurchase_price(String purchase_price) {
        this.purchase_price = purchase_price;
    }

    public String getPurchase_amount() {
        return purchase_amount;
    }

    public void setPurchase_amount(String purchase_amount) {
        this.purchase_amount = purchase_amount;
    }

    public PurchaseData()
    {

    }
}
